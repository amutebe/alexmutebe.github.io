widgets = {'date_today': HiddenInput(), 'status':HiddenInput(), 'co_code':HiddenInput(),'record_group':HiddenInput(),'entered_by':HiddenInput(),
'target': forms.Textarea(attrs={'rows':1, 'cols': 40}),'date': DateInput(),'due':DateInput(),
'kpi_details':forms.Textarea(attrs={'rows':1, 'cols': 40}),'eva_by':forms.Textarea(attrs={'rows':1, 'cols': 40}),
'details':forms.Textarea(attrs={'rows':1, 'cols': 40}),'measurement_no':forms.Textarea(attrs={'rows':1, 'cols': 40}),
'result':forms.Textarea(attrs={'rows':1, 'cols': 40}),'target_archievement':forms.Textarea(attrs={'rows':1, 'cols': 40}))}
