import pandas as pd 
from sqlalchemy import create_engine
import mysql.connector

courses = {'Courses':['English','French','German','Spanish'],
           'Duration_in_days':['35','35','40','30']}


df = pd.DataFrame.from_dict(courses)

df

try:
    mydb = mysql.connector.connect(
        host="localhost",
        user="sa",
        password="JosHa1234!", port='3308')
    
    print("Connection established")

    cursor = mydb.cursor()

    cursor.execute("create database if not exists new_db")
    mydb.commit()
    print("Database created successfully")
    cursor.execute("use new_db")
    #cursor.close()
    #mydb.close()

except mysql.connector.Error as err:
    print("An error occurred:", err)


hostname= "localhost"
database= "new_db"
username= "sa"
password= "JosHa1234!"
prt=3308

engine = create_engine("mysql+pymysql://{user}:{pw}@{host}:{port}/{db}".format(host=hostname, db=database, user=username, pw=password,port=prt))











df.to_sql('table1', engine, if_exists='replace', index=False)